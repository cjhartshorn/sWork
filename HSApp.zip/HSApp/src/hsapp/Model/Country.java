/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsapp.Model;

/**
 *
 * @author christina joy hartshorn
 */
public class Country {
    protected int countryId;
    protected String countryName;
    
    public Country(int countryId, String countryName)
    {
        this.countryId = countryId;
        this.countryName = countryName;
    }
    
    public int getCountryId()
    {
        return countryId;
    }
    
    public void setCountryId(int countryId)
    {
        this.countryId = countryId;
    }
    
    public String getCountryName()
    {
        return countryName;
    }
    
    public void setCountryName(String countryName)
    {
        this.countryName = countryName;
    }
    
}
