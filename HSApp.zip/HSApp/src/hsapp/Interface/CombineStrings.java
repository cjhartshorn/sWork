/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hsapp.Interface;

/**
 *
 * @author christina joy hartshorn
 */
public interface CombineStrings {
    //to combine String in report
    String combineString(String s);
}
